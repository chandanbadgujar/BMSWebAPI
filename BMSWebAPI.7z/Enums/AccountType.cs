﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMSWebAPI.Enums
{
    public enum AccountType
    {
        Savings = 1,
        Salary = 2
    }
}
