﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMSWebAPI.Constants
{
    public class Configurations
    {
        public const int savingsInitialDepositAmountLimit = 5000;
        public const int salaryInitialDepositAmountLimit = 0;
    }
}
